
/*:
 # CodeXperience
 
 ---
 
 Welcome to my WWDC AR Playground
 
 This playground shows a funny way to enjoy and make the most of Augmented Reality tools 🛠.
 Try completing the goals to get a teleportation pass to WWDC 19.
 
 ### Interactions
 1. Allow the playground to access your camera.
 2. Go for an open space to begin.
 3. Find the right password an tap them in order.
 4. Step inside the teleportation basis.
 5. If you want to play again, restart the playground.
 
 ---
 
 - Note: Please test on iPad Pro versions.
 
 ---
 
 Change the confetti colors to see new effects.
 
 Hope you enjoy my playground!
 */
//#-hidden-code

import UIKit
import PlaygroundSupport

let settings = Settings()
var confettiColor1 = UIColor.green
var confettiColor2 = UIColor.green
if #available(iOS 11.0, *){
    
    
    let start = ArKitViewController()
    //**************************************
    //#-end-hidden-code
    
    // Change confettis color
    confettiColor1 = /*#-editable-code*/#colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)/*#-end-editable-code*/
    confettiColor2 = /*#-editable-code*/#colorLiteral(red: 0.7450980544, green: 0.1568627506, blue: 0.07450980693, alpha: 1)/*#-end-editable-code*/
    
    //#-hidden-code
    
    settings.confettiColor1 = confettiColor1
    settings.confettiColor2 = confettiColor2
    
    start.settings = settings
    
    PlaygroundPage.current.liveView = start
    PlaygroundPage.current.needsIndefiniteExecution = true
}
else {}
//#-end-hidden-code


