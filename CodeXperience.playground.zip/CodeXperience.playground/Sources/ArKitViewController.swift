
//  WWDC19
//
//  Created by Annderson Packeiser Oreto.
//  Copyright © 2019 Annderson Packeiser Oreto. All rights reserved.
//

import Foundation
import UIKit
import SceneKit
import ARKit
import SpriteKit

@available(iOS 11.0, *)
public class ArKitViewController: UIViewController, ARSessionDelegate, ARSCNViewDelegate {
    var sceneView: ARSCNView!
    let session = ARSession()
    
    var nodesList: [SCNNode] = []
    var nodesNumber: [Int] = []
    var scene3: SKScene?
    
    //************
    var spawnLine = false
    var spawnTime:TimeInterval = 0
    var password = ""
    var confirmacao = true
    var teleport = true
    var begin = false
    var passwordList: [Int] = []
    
    
    var lineColor = UIColor.white
    
    public var settings = Settings()
    
    override public func loadView() {
        
        sceneView = ARSCNView(frame: CGRect(x: 0.0, y: 0.0, width: 1024.0, height: 768.0))
        
        sceneView.delegate = self
        sceneView.session.delegate = self
        sceneView.session = session
        sceneView.showsStatistics = true
        
        let scene = SCNScene()
        sceneView.scene = scene
        
        //Create TapGesture Recognizer
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        
        sceneView.addGestureRecognizer(tap)
        
        let config = ARWorldTrackingConfiguration()
        
        // lighting
        let nonAmbientLightNode = SCNNode()
        nonAmbientLightNode.light = SCNLight()
        nonAmbientLightNode.light?.type = .ambient
        nonAmbientLightNode.light?.color = UIColor.white
        nonAmbientLightNode.light?.intensity = 500
        sceneView.scene.rootNode.addChildNode(nonAmbientLightNode)
        
        // setup camera
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 10, y: 10, z: 10)
        sceneView.scene.rootNode.addChildNode(cameraNode)
        
        self.view = sceneView
        sceneView.session.run(config, options: [.removeExistingAnchors])
        
        begin1()
        
    }
    
    func showSceneStatistics(_ show: Bool){
        
    }
    
    override open func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override open func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    // MARK: - ARSCNViewDelegate
    public func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        DispatchQueue.main.async {
            if time > self.spawnTime {
                self.spawnLine = true
                self.spawnTime = time + TimeInterval(0.008)
            }
            else {self.spawnLine = false}
        }
    }
    
    public  func renderer(_ renderer: SCNSceneRenderer, willRenderScene scene: SCNScene, atTime time: TimeInterval) {
        if !confirmacao && teleport {
            let position = sceneView.pointOfView?.position
            if position!.x >= Float(-2.0) && position!.x <= Float(-1.0) && position!.z >= Float(-2.0) && position!.z <= Float(-1.0) {
                teleport = false
                thirdScene()
            }
        }
    }
    
    //Method called when tap
    @objc func handleTap(_ rec: UITapGestureRecognizer){
        if !begin {
            begin = true
//            scene3!.anchorPoint = CGPoint(x: 1, y: 1)
            scene3?.removeAllChildren()
            drawFigures()
        }
        let location = rec.location(in: rec.view as! SCNView)
        let hit = sceneView.hitTest(location, options: nil)
        if !hit.isEmpty {
            let result = hit.first
            if result?.node.geometry is SCNBox && confirmacao {
                var index = 0
                for nodes in nodesList {
                    if result?.node == nodes {
                        break
                    }
                    index += 1
                }
                    if nodesNumber[index] == passwordList[0] {
                        result?.node.runAction(SCNAction.fadeOut(duration: 0.8))
                        passwordList.removeFirst()
                    }
                if passwordList.count <= 0 && confirmacao {
                    confirmacao = false
                    secondScene()
                }
            } else if result?.node.geometry is SCNText && !confirmacao {
                for nodes in nodesList {
                    nodes.removeFromParentNode()
                }
                scene3?.removeAllChildren()
                let label1 = SKLabelNode(text: "Thanks for playing. Hope to see you on WWDC.")
                label1.fontSize = 28
                label1.fontColor = UIColor.white
                label1.position = CGPoint(x: scene3!.size.width/2, y: scene3!.size.height/2)
                scene3?.addChild(label1)
            }
        }
        
    }
    
    func secondScene() {
        for nodes in nodesList {
            nodes.runAction(SCNAction.sequence([SCNAction.scale(to: 2.0, duration: 1.0), SCNAction.scale(to: 0.0, duration: 0.2)]))
        }
        nodesList.removeAll()
        scene3!.removeAllChildren()
        let label1 = SKLabelNode(text: "Password correct.")
        label1.fontSize = 28
        label1.fontColor = UIColor.white
        label1.position = CGPoint(x: scene3!.size.width/2, y: scene3!.size.height-40)
        scene3?.addChild(label1)
        
        let label2 = SKLabelNode(text: "Find the teleport and step in to enter the WWDC.")
        label2.fontSize = 28
        label2.fontColor = UIColor.white
        label2.position = CGPoint(x: scene3!.size.width/2, y: scene3!.size.height-80)
        scene3?.addChild(label2)
        let circle = SCNCylinder(radius: 0.5, height: 0.0)
        circle.firstMaterial?.diffuse.contents = UIColor.blue
        let circleNode = SCNNode(geometry: circle)
        circleNode.position = SCNVector3(x: -1.5, y: -1.5, z: -2.0)
        sceneView.scene.rootNode.addChildNode(circleNode)
        nodesList.append(circleNode)
//        for x in 2..<5 {
//        let text = SCNTube(innerRadius: 0.5, outerRadius: 0.5, height: 0.1)
//            text.firstMaterial?.diffuse.contents = UIColor.cyan
//        // text.firstMaterial?.diffuse.contents = UIColor.red
//        let textNode = SCNNode(geometry: text)
//        textNode.position = SCNVector3(x: -1.5, y: Float(Float(x) * -0.3), z: -2.0)
//        sceneView.scene.rootNode.addChildNode(textNode)
////            textNode.runAction(SCNAction.repeatForever(SCNAction.sequence([SCNAction.move(to: SCNVector3(x: Float(textNode.position.x), y: 2.0, z: Float(textNode.position.z)), duration: 2.0), SCNAction.move(to: SCNVector3(x: Float(textNode.position.x), y: -1.5, z: Float(textNode.position.z)), duration: 0.0)])))
//            textNode.runAction(SCNAction.repeatForever(SCNAction.sequence([SCNAction.fadeOut(duration: 2.0), SCNAction.fadeIn(duration: 2.0)])))
//            nodesList.append(textNode)
//        }
    }
    
    func thirdScene() {
        for nodes in nodesList {
            nodes.removeFromParentNode()
        }
        nodesList.removeAll()
        scene3!.removeAllChildren()
        let n = 500.0
        for _ in 0..<Int(n) {
            let box = SCNBox(width: 0.05, height: 0.05, length: 0.0, chamferRadius: 0.0)
            let boxMaterial = SCNMaterial()
            let number = Int.random(in: 1...3)
            nodesNumber.append(number)
            if number == 1 {
                boxMaterial.diffuse.contents = settings.confettiColor1
            } else if number == 2 {
                boxMaterial.diffuse.contents = settings.confettiColor2
            } else {
                boxMaterial.diffuse.contents = UIColor.yellow
            }
            box.materials = [boxMaterial]
            let boxNode = SCNNode(geometry: box)
            boxNode.position = SCNVector3(x: Float.random(in: -2.0...2.0), y: 2.0, z: Float.random(in: -2.0...2.0))
            sceneView.scene.rootNode.addChildNode(boxNode)
            boxNode.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0.1, y: 0.1, z: 0.1, duration: 0.05)))
            boxNode.runAction(SCNAction.repeatForever(SCNAction.sequence([SCNAction.move(to: SCNVector3(x: boxNode.position.x, y: -1.0, z: boxNode.position.z), duration: Double.random(in: 2.0...10.0)), SCNAction.move(to: SCNVector3(x: boxNode.position.x, y: 2.0, z: boxNode.position.z), duration: 0.0)])))
            nodesList.append(boxNode)
        }
        
        let text = SCNText(string: "CONGRATULATIONS!\n            exit", extrusionDepth: CGFloat(0.05))
        text.font = UIFont(name: "Helvetica", size: CGFloat(0.6))
        // text.firstMaterial?.diffuse.contents = UIColor.red
        let textNode = SCNNode(geometry: text)
        textNode.position = SCNVector3(x: -1.5, y: -0.2, z: -6.0)
        sceneView.scene.rootNode.addChildNode(textNode)
        nodesList.append(textNode)
        nodesNumber.append(0)
    }
    
    func begin1() {
        scene3 = SKScene(size: sceneView.frame.size)
        
        let label1 = SKLabelNode(text: " WWDC 19")
        label1.fontSize = 40
        label1.fontColor = UIColor.white
        label1.position = CGPoint(x: scene3!.size.width/2, y: scene3!.size.height+40)
        label1.run(SKAction.move(to: CGPoint(x: scene3!.size.width/2, y: scene3!.size.height/2+40), duration: 2.0))
        label1.run(SKAction.scale(by: 1.5, duration: 2.0))
        //        label1.verticalAlignmentMode = .center
        //        label1.horizontalAlignmentMode = .center
        let label2 = SKLabelNode(text: "Tap anywhere to start")
        label2.fontSize = 20
        label2.fontColor = UIColor.white
        label2.position = CGPoint(x: scene3!.size.width/2, y: scene3!.size.height/2)
        label2.run(SKAction.repeatForever(SKAction.sequence([SKAction.fadeOut(withDuration: 1.0), SKAction.fadeIn(withDuration: 1.0)])))
        
        
        let background = SKSpriteNode(color: .black, size: scene3!.size)
        background.anchorPoint = CGPoint(x: 0, y: 0)
        scene3?.addChild(background)
        
        scene3?.addChild(label2)
        scene3?.addChild(label1)
        sceneView.overlaySKScene = scene3
    }
    
    func drawFigures(){
        for _ in 0...2 {
            let randomPassword1 = Int.random(in: 1...3)
            password += "\(randomPassword1) "
            passwordList.append(randomPassword1)
        }
        
        let label1 = SKLabelNode(text: "Click the password numbers in sequence to unlock teleport slab.")
        label1.fontSize = 28
        label1.fontColor = UIColor.white
        label1.position = CGPoint(x: scene3!.size.width/2, y: scene3!.size.height-40)
        scene3?.addChild(label1)
        
        let label2 = SKLabelNode(text: "Turn around to find the password.")
        label2.fontSize = 28
        label2.fontColor = UIColor.white
        label2.position = CGPoint(x: scene3!.size.width/2, y: scene3!.size.height-80)
        scene3?.addChild(label2)
        
        let text = SCNText(string: "Password\n    \(password)", extrusionDepth: CGFloat(0.05))
        text.font = UIFont(name: "Helvetica", size: CGFloat(0.6))
        // text.firstMaterial?.diffuse.contents = UIColor.red
        let textNode = SCNNode(geometry: text)
        textNode.position = SCNVector3(x: -1.5, y: -0.2, z: -6.0)
        sceneView.scene.rootNode.addChildNode(textNode)
        nodesList.append(textNode)
        nodesNumber.append(0)
        
        let light = SCNLight()
        light.type = SCNLight.LightType.omni
        let lightBox = SCNNode()
        lightBox.light = light
        lightBox.position = SCNVector3(x: 0.0, y: 0.2, z: 0.8)
        sceneView.scene.rootNode.addChildNode(lightBox)
        
        var height = 0.05
        let n = 20.0
        for x in 0..<Int(n) {
            let box = SCNBox(width: 0.4, height: 0.4, length: 0.4, chamferRadius: 0.05)
            let boxMaterial = SCNMaterial()
            let number = Int.random(in: 1...3)
            nodesNumber.append(number)
            boxMaterial.diffuse.contents = UIImage(named: "number\(number).png")
            box.materials = [boxMaterial]
            let boxNode = SCNNode(geometry: box)
            boxNode.position = SCNVector3(x: Float(n / 4.0) * Float(cos(((2 * Double.pi) / n) * Double(x))), y: -0.1, z: Float(n / 4.0) * Float(sin(((2 * Double.pi) / n) * Double(x))))
            sceneView.scene.rootNode.addChildNode(boxNode)
            height += 0.05
            nodesList.append(boxNode)
        }
        
    }
    
}


