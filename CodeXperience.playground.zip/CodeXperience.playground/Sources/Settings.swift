import Foundation
import PlaygroundSupport
import UIKit

open class Settings {
    
    //Line Settings
    public var confettiColor1 = UIColor.orange
    public var confettiColor2 = UIColor.orange
    
    
    public init(){}
    
}



